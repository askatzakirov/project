<?php

    $con=mysqli_connect('localhost','root','','user');

    if(!$con)
    {
        die(' Please Check Your Connection'.mysqli_error($con));
    }

?>
