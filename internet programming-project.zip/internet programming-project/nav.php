<?php
  session_start();
  include "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title>navbar</title>
  <link rel="stylesheet" type="text/css" href="nav.css">
  <link rel="stylesheet" t href="home.php">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="~/lib/Font-Awesome/css/fontawesome.min.css">
  <link rel="stylesheet" href="~/lib/Font-Awesome/css/regular.min.css">
  <link rel="stylesheet" href="~/lib/Font-Awesome/css/solid.min.css">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script src=”https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js”></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" 
        href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" 
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" 
        crossorigin="anonymous">
</head>
<body>
<section id="nav-bar">
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#"><img src="images\logoo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="menu.php">Menu</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="home.php #aboutt">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="home.php #contact">Contact</a>
          </li>
          <div class="user">
            <?php 
              echo "<font color='white'>".'Welcome '.($_SESSION['username'])."</font>";  
            ?>
          </div>
          <div>
            <br>
              <a href="login.php" style="margin-right: 20px;">Log out</a>
          </div>
        </ul>
    </div>
</nav>
</section>
</body>
</html>