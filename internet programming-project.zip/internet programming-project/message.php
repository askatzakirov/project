<?php 
	include "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>message</title>
	<link rel="stylesheet" type="text/css" href="nav.css">

<script type="text/javascript">
	var count=0;
	$(document).ready(function(){
	$("#button1").click(function(){
		count=count+1;
		$("#mess").load("loadmessages.php",{newcount:count});
		});
	});		
</script>
</head>
<body>
<div id="mess">
<?php
	$sq="SELECT * FROM contact LIMIT 0";
	$result = mysqli_query($con,$sq);
	if(mysqli_num_rows($result)>0){
		echo "<table class='tablee'>";
			echo "<tr>";
				echo "<th>"; echo "Username";     echo "</th>";
				echo "<th>"; echo "Name";         echo "</th>";
				echo "<th>"; echo "Country code"; echo "</th>";
				echo "<th>"; echo "Phone Number"; echo "</th>";
				echo "<th>"; echo "Mail";         echo "</th>";
				echo "<th>"; echo "Message";      echo "</th>";
			echo "<tr>";
			while($row=mysqli_fetch_assoc($result)){?>
				<tr> 
					<td><?php  echo $row['username'];  ?> </td>
					<td><?php  echo $row['name'];      ?> </td>
					<td><?php  echo $row['phonecode']; ?> </td>
					<td><?php  echo $row['phone'];     ?> </td>
					<td><?php  echo $row['mail'];      ?> </td>
					<td><?php  echo $row['text'];      ?> </td>
				</tr>
			<?php
			}
		echo "</table>";
	}
	else{
		echo "There are no messages";
	}
?>
	

</div>
<input type="button" id="button1" value="Show more messages ">
</body>
</html>