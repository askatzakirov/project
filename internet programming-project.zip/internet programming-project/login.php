<?php
    session_start();
    include "connect.php";
    
    if(isset($_POST['login'])){
        $temp=0;
        $username=$_POST['username'];
        $query="SELECT * FROM user WHERE username ='$_POST[username]' && password='$_POST[password]';";
        $fin=mysqli_query($con,$query);
        $temp=mysqli_num_rows($fin);
        if($temp==0){
            ?>
            <script type="text/javascript">
                alert("incorrect username or password");
            </script>
            <?php
        }
        else{

            $_SESSION['username']=$username;
            header("location:nav.php");
            header("location:loadmessages.php");
            header("location:menu.php"); 
            header("location:home.php");
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="login.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/regular.min.css">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/solid.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" ></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<script src=”https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js”></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" 
	      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" 
	      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" 
	      crossorigin="anonymous">
	<style>
	body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 300px;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 250px;
  float-left: 700px: 
}

button:hover {
  opacity: 0.8;
}

.sign {
  width: auto;
  padding: 10px 18px;
  background-repeat: no-repeat;
  background-size: 30px 100px ;

}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 15%;
  border-radius: 20%;
}

.container {
   
  padding: 16px;
  margin-left: 600px;
}
#textt{
	margin-left: 100px;
}
span.psw {
  float-right: 150px;
  padding-top: 16px;
  margin-right: 400px
}
#sign{
	margin-left: 400px;
	background-repeat: no-repeat;
  	background-size: auto;
}

</style>
</head>
<body>
<br>
<h2 style="text-align: center;">Login Form</h2>
<div>
    <form action="" method="post" style="display:inline;">
  <div class="imgcontainer">
    <img src="images\login.png" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="username" id="text"><b>Username</b></label>&nbsp;&nbsp;
    <input type="text" placeholder="Enter Username" name="username">
    <br>
    <label for="password" id="text"><b>Password</b></label>&nbsp;&nbsp;
    <input type="password" placeholder="Enter Password" name="password">
     <br>
    <button type="submit" id="textt" name="login">&nbsp;Login</button>
    <br>
    <label>
      <input type="checkbox" checked="checked" name="remember" id="textt"> Remember me
    </label>
  </div>

  <div class="container" style="color: red" id="sign">
    <a href="sign.php" id="sign"><mark style="background-color: #ddd; size: 20px 50px;">Sign Up</mark></a>
    <br>
  </div>
</form>
</div>
<script type="text/javascript">
    bgcolor: 
</script>
</body>
</html>