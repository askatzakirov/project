-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 12, 2020 at 03:57 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `username` varchar(10) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `text` text NOT NULL,
  `name` varchar(15) NOT NULL,
  `phonecode` varchar(5) NOT NULL,
  PRIMARY KEY (`username`,`mail`,`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`username`, `mail`, `phone`, `text`, `name`, `phonecode`) VALUES
('asko_lax', '', '', '', '', '44'),
('1234', 'asdfghj@gmail.com', '3456788', 'asdfghj wertyyiu wqertyui', 'das', '880'),
('1234', 'asdfghj@gmail.com', '3245678543', 'zaxsdcfgb esrdtyfukibv trytuyu ', 'fgfhhg', '375'),
('user', 'sdfggh@gmail.com', '3456788', 'asdfghjk fdgh wretyjh wwertyu wee45rytu dwerthyn qdwedfs ', 'baiastan', '501'),
('asko_lax', 'asko2gmail.com', '3456788', 'sdsdgf tyguhijl', 'asko', '44'),
('asko_lax', 'as', '3456788', 'easrdtfg', 'Askat', '44'),
('asko_lax', 'asko2gmail.com', '76676767', 'xfgh gchjvh cvjknml', 'Askat', '376'),
('user67', 'asko2gmail.com', '36787634', 'awesome website\r\n', 'Askat', '269'),
('user47', 'asko2gmail.com', '234567879', 'welcome ', 'Askat', '375'),
('user38', 'asko2gmail.com', '34565764', 'welcome', 'Askat', '244'),
('user45', 'asko2gmail.com', '34567645', 'thanks', 'Askat', '90392');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('asko_lax', 'asko9999'),
('user', 'user'),
('user1', 'user1'),
('user51', 'user51'),
('1234', '1234'),
('12345', '12345'),
('user123', 'user123'),
('user67', 'user67'),
('user47', 'user47'),
('user38', 'user38'),
('user45', 'user45');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
