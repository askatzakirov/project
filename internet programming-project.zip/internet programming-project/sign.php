<?php
	include "connect.php";
	if (isset($_POST['register'])){
		$count=0;
		$sql="select username from user";
		$res=mysqli_query($con,$sql);
		while ($row=mysqli_fetch_assoc($res)){
			if($row['username']==$_POST['username']){
				$count+=1;
			}

		}

		if ($_POST['password']!=$_POST['password2']) {
		?>
			<script type="text/javascript">
				alert("Two passwords do not match");
			</script>
		<?php
		}
		else{
			if($count==0)
			{
				mysqli_query($con,"INSERT INTO user(username,password) values ('$_POST[username]','$_POST[password]')");
				?>
				<script type="text/javascript">
					alert("Regitered succesfully");
					window.location("login.php");
				</script>
				<?php
			}
			else{
				?>
				<script type="text/javascript">
					alert("Alredy exist");
				</script>
				<?php
			}
		}
	}
?>     
<!DOCTYPE html>
<html>
<head>
 <title> Login Form in HTML5 and CSS3</title>
 <link rel="stylesheet" a href="sign.css">
 <link rel="stylesheet" a href="css\font-awesome.min.css">
</head>
<body>
 <div class="container">
 <img src="images\sign.png"/>
 <form action="" method="post">
 <div class="form-input">
 <input type="text" name="username" placeholder="username"/> 
 </div>
 <div class="form-input">
 <input type="password" name="password" placeholder="password"/>
 <div class="form-input">
 <input type="password" name="password2" placeholder="confirmation password"/>
 </div>
 <input type="submit" name="register" value="register" class="btn-login"/>
 <a href="login.php">&nbsp;&nbsp;Already has an account</a>
 </form>
 </div>
</body>
</html>