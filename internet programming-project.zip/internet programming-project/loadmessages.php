<?php 
	include "connect.php";
	$newcount=$_POST['newcount'];

	$sq="SELECT * FROM contact LIMIT $newcount";
		$result = mysqli_query($con,$sq);
		if(mysqli_num_rows($result)>0){
			echo "<table class='table'>";
			echo "<tr>";
				echo "<th>"; echo "Username"; echo "</th>";
				echo "<th>"; echo "Name"; echo "</th>";
				echo "<th>"; echo "Country code"; echo "</th>";
				echo "<th>"; echo "Phone Number"; echo "</th>";
				echo "<th>"; echo "Mail"; echo "</th>";
				echo "<th>"; echo "Message"; echo "</th>";
			echo "<tr>";
			while($row=mysqli_fetch_assoc($result)){?>
				<tr> 
					<td><?php  echo $row['username']; ?> </td>
					<td><?php  echo $row['name']; ?> </td>
					<td><?php  echo $row['phonecode']; ?> </td>
					<td><?php  echo $row['phone']; ?> </td>
					<td><?php  echo $row['mail']; ?> </td>
					<td><?php  echo $row['text']; ?> </td>
				</tr>
			<?php
			}
			echo "</table>";
		}else{
			 echo "There are no messages";
		}
						
?>