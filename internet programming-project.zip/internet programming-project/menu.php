<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<link rel="stylesheet" type="text/css" href="menu.css">
	<link rel="stylesheet" type="text/css" href="nav.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/regular.min.css">
	<link rel="stylesheet" href="~/lib/Font-Awesome/css/solid.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" ></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<script src=”https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js”></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" 
	      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" 
	      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" 
	      crossorigin="anonymous">
</head>
<body background="#ddd">
<?php include 'nav.php'; ?>
<section>
	<div class="div">
		<div class="div1">
			<table >
				<tr>
					<th colspan="3">
						<a>Pizza</a><br><br>
					</th>
				</tr>
				<tr>
					<td>
						<img src="images\1.jpg" width="100" height="80">
					</td>
					<td>
						Carpacio
					</td>
					<td>
						25 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\2.jpg" width="100" height="80">
					</td>
					<td>
						ASAR Pizza
					</td>
					<td>
						30 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\3.jpg" width="100" height="80">
					</td>
					<td>
						Margarita
					</td>
					<td>
						20 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\4.jpg" width="100" height="80">
					</td>
					<td>
						Hawaian
					</td>
					<td>
						25 TL
					</td>
				</tr>
				<tr>
					<th colspan="3">
						Burgers<br><br>
					</th>
				</tr>
				<tr>
					<td>
						<img src="images\5.jpg" width="100" height="80">
					</td>
					<td>
						Chicken Burger
					</td>
					<td>
						25 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\6.jpg" width="100" height="80">
					</td>
					<td>
						ASAR Burger
					</td>
					<td>
						30 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\7.jpg" width="100" height="80">
					</td>
					<td>
						Special Burger
					</td>
					<td>
						30 TL
					</td>
				</tr>
				<tr>
					<td>
						<img src="images\8.jpg" width="100" height="80">
					</td>
					<td>
						Kids Brger
					</td>
					<td>
						25 TL
					</td>
				</tr>
			</table>
		</div><br><br>
		<div class="div2">
			<div>
				<table>
					<tr>
						<th colspan="3">
							Doner<br><br>
						</th>
					</tr>
					<tr>
						<td>
							<img src="images\13.jpg" width="100" height="80">
						</td>
						<td>
							Chicken Doner
						</td>
						<td>
							25 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\14.jpg" width="100" height="80">
						</td>
						<td>
							ASAR Doner
						</td>
						<td>
							30 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\15.jpg" width="100" height="80">
						</td>
						<td>
							Beef Doner
						</td>
						<td>
							20 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\16.jpg" width="100" height="80">
						</td>
						<td>
							Double Doner
						</td>
						<td>
							 40 TL
						</td>
					</tr>
					<tr>
						<th colspan="3">
							Drinks<br><br>
						</th>
					</tr>
					<tr>
						<td>
							<img src="images\9.jpg" width="100" height="80">
						</td>
						<td>
							Coco Cola
						</td>
						<td>
							5 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\10.jpg" width="100" height="80">
						</td>
						<td>
							Pepsi
						</td>
						<td>
							8 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\12.jpg" width="100" height="80">
						</td>
						<td>
							Ayran
						</td>
						<td>
							5 TL
						</td>
					</tr>
					<tr>
						<td>
							<img src="images\11.jpg" width="100" height="80">
						</td>
						<td>
							Water
						</td>
						<td>
							3 TL
						</td>
					</tr>
				</table>
		</div>
	</div>
</section>
</body>
</html>